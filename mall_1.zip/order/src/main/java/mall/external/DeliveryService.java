
package mall.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;

@FeignClient(name="delivery", url="http://localhost:8082")
public interface DeliveryService {

    // Call Delivery Repository-Exposed Command API. 
    //@RequestMapping(method= RequestMethod.DELETE, path="/deliveries/{id}")
    //public void cancelDelivery(@PathVariable String id);

    // Call Delivery Controller-Exposed Command API. 
    @RequestMapping(method= RequestMethod.DELETE, path="/deliveries/cancelDelivery")
    public Boolean cancelDelivery(@RequestParam String id);

}